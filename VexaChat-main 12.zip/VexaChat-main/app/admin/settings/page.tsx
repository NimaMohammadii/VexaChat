export default function SettingsPage() {
  return (
    <section className="space-y-4">
      <h1 className="text-3xl font-semibold">Settings</h1>
      <p className="rounded-xl border border-line bg-slate p-4 text-sm text-white/80">Settings placeholder.</p>
    </section>
  );
}
