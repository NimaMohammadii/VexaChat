export default function MediaPage() {
  return (
    <section className="space-y-4">
      <h1 className="text-3xl font-semibold">Media</h1>
      <p className="rounded-xl border border-line bg-slate p-4 text-sm text-white/80">Media library placeholder.</p>
    </section>
  );
}
